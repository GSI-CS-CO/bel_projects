#include <fstream>
#include <iostream>
#include <streambuf>
#include <stdint.h>

#include "lzmaCompression.h"

int main(int argc, char **argv) {
  if (argc > 3) {
    std::string inFileName = std::string(argv[1]);
    std::string outFileName = std::string(argv[2]);
    std::string outFileNameBin = std::string(argv[3]);
    std::ifstream fTextIn(inFileName);
    std::string tmpStrBuf((std::istreambuf_iterator<char>(fTextIn)), std::istreambuf_iterator<char>());
    //~ fTextIn >> tmpStrBuf;
    fTextIn.close();
    //~ std::cout << '"' << tmpStrBuf << '"' << std::endl;
    std::ofstream fTextOut(outFileName);
    fTextOut << tmpStrBuf;
    fTextOut.close();
    vBuf tmpBuf(tmpStrBuf.begin(), tmpStrBuf.end());
    vBuf tmpBufBinary = lzmaCompress(tmpBuf);
    std::ofstream fBinOut(outFileNameBin, std::ios::out | std::ios::binary);
    fBinOut.write((char*)&tmpBufBinary[0], tmpBufBinary.size() * sizeof(uint8_t));
    fBinOut.close();
  } else {
    std::cout << "Usage: " << std::string(argv[0]) << " <input file name>" << " <output file name>" << " <bin output file name>" << std::endl;
  }
}
