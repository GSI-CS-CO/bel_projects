#ifndef _LZMA_COMPRESSION_H_
#define _LZMA_COMPRESSION_H_


#include <stdio.h>
#include <stdint.h>
#include <string>
#include <vector>
#include <stdexcept>

#include "LzmaEnc.h"
#include "LzmaDec.h"

typedef std::vector<uint8_t> vBuf; ///< buffer for WB payload data

//~ static void *_lzmaAlloc(ISzAllocPtr, size_t size);

//~ static void _lzmaFree(ISzAllocPtr, void *addr);

//~ static ISzAlloc _allocFuncs;

vBuf lzmaCompress(const vBuf& input);

vBuf lzmaDecompress(const vBuf& input);

#endif
