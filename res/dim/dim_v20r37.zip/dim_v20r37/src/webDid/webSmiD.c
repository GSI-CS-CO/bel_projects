#include <stdio.h>                   
#include <ctype.h>
#include <time.h>
#include <dim.h>
#include <dic.h>
#include <dis.h>

extern int WebDID_Debug;

